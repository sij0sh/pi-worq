import { Type } from "typebox";
import { createHash, randomUUID } from "node:crypto";
import { renameSync, writeFileSync } from "node:fs";
import { mkdir, rm } from "node:fs/promises";
import { join } from "node:path";
import { Block, errorText, obj, PqAnswer, ReviewReport, Submission, text, type Verdict } from "./contracts.ts";
import type { Limits } from "./runtime/config.ts";
import { git } from "./process.ts";
import type { Kind, Prompts } from "./prompts.ts";
import { clean, DIGEST, one, planMarkdown, pqMessage, reportText, reviewLines, reviewStatus, type ReviewRecord } from "./render.ts";
import { Conversation, type Sessions } from "./session.ts";
import { tool, type Driver, type Runtime, type Tool } from "./sdk/contract.ts";
import { runSubagent, type Semaphore, type SubagentDeps, type Workspace } from "./subagent.ts";
import { processTools, readTools, writeTools } from "./tools.ts";
import { agentDirectory, baselineProject, intact, pin, removeWorktree, snapshot, worktree, writeScoped, type Project } from "./workspace.ts";
import type { Revision, Telemetry } from "./telemetry.ts";

/** parked: submitted (or out of budget), session and worktree retained until Main resumes or closes it. */
export type AgentState = "starting" | "running" | "waiting" | "reviewing" | "parked" | "closed" | "cancelled" | "failed";
export const ENDED: AgentState[] = ["closed", "cancelled", "failed"];
export interface AgentEvent { type: "parked" | "ask" | "warning" | "failed"; ref: string; text: string }
export interface Attachment { path: string; text: string }
export interface Delegation { role: string; id: string; question: string; why: string; state: "queued" | "running" | "answered" | "failed" | "cancelled"; answer?: PqAnswer; error?: string }
export const UNANSWERED = "Main did not answer in time. Missing authorization is not approval. Stop the affected work and report the unresolved decision.";

export interface AgentDeps {
  telemetry?: Telemetry;
  driver: Driver;
  prompts: Prompts;
  limits: Limits;
  state: string;
  root: string;
  semaphore: Semaphore;
  notify(event: AgentEvent): void;
  /** The admitted runtime; PQ and review children inherit the owner's effective runtime. */
  runtime?: Runtime;
  /** Live controllable sessions, keyed by telemetry row key. */
  sessions?: Sessions;
}

/**
 * One Main-spawned SDK agent. Each round: running (may delegate PQs, ask Main) → submit →
 * one independent review (when the profile asks) → parked. Main resumes it with worq_send or closes it.
 * Never spawns, retries or merges on its own.
 */
export class Agent {
  readonly id = randomUUID();
  readonly ref: string;
  readonly kind: Kind;
  readonly task: string;
  readonly attachments: Attachment[];
  readonly title: string;
  /** The package's review policy. */
  readonly reviewed: boolean;
  readonly branch?: string;
  readonly owner = process.pid;
  state: AgentState = "starting";
  round = 0;
  started = Date.now();
  finished?: number;
  error?: string;
  /** Pinned commit of the latest submission. */
  candidate?: string;
  /** Unreviewed commit of work left by budget exhaustion or close. */
  recoverySha?: string;
  /** Why the latest round parked without a submission. */
  exhausted?: string;
  diffstat?: string;
  plan?: { path: string; text: string };
  work?: string;
  submission?: string;
  readonly reviews: ReviewRecord[] = [];
  readonly delegations: Delegation[] = [];
  readonly launches: { role: string; runtime: Runtime; label?: string }[] = [];
  ask?: { question: string; resolve(answer: string): void };
  readonly done: Promise<void>;
  private readonly history: { seq: number; line: string }[] = [];
  private seq = 0;
  private dir?: string;
  private project?: Project;
  private conversation?: Conversation<typeof Submission>;
  private asks = 0;
  private wakeParked?: (message: string | undefined) => void;
  private readonly controller = new AbortController();
  private readonly deps: AgentDeps;
  private start!: () => void;
  private warning = (message: string) => {
    this.log(message);
    this.deps.notify({ type: "warning", ref: this.ref, text: `${this.headline} ${message}` });
  };

  constructor(deps: AgentDeps, input: { ref: string; title?: string; dir?: string; kind: Kind; task: string; attachments: Attachment[] }) {
    this.deps = deps;
    this.ref = input.ref;
    this.title = input.title ?? input.ref;
    this.dir = input.dir;
    this.kind = input.kind;
    if (deps.runtime) this.launches.push({ role: `agent.${input.kind.name}`, runtime: deps.runtime });
    this.task = input.task;
    this.attachments = input.attachments;
    this.reviewed = input.kind.review;
    if (input.kind.access === "write") this.branch = `worq/${input.ref}`;
    const begun = new Promise<void>((resolve) => { this.start = resolve; });
    this.done = begun.then(() => this.run());
  }
  get headline() { return `${this.title} (${this.ref}) · ${this.kind.name}`; }
  get signal() { return this.controller.signal; }
  get ended() { return ENDED.includes(this.state); }
  /** Idle sessions hold no execution slot. */
  get active() { return !this.ended && this.state !== "parked"; }
  get openPqs() { return this.delegations.filter((d) => d.state === "queued" || d.state === "running").length; }
  /** The current round's review, if it ran. */
  get review() { return this.reviews.find((r) => r.round === this.round); }
  launch() {
    this.deps.telemetry?.add(this.id, this.ref, this.kind.name, undefined, undefined, undefined, this.title);
    this.deps.sessions?.set(this.id, {
      key: this.id, ref: this.ref, role: `agent.${this.kind.name}`, label: this.headline,
      consequence: "Stops the agent and every PQ and review it owns; its branch is kept.",
      runtime: () => this.conversation?.runtime ?? this.deps.runtime,
      pending: () => this.conversation?.pendingChange,
      cancel: async () => { await this.cancel(); return `${this.ref} ${this.state}`; },
      configure: (change) => {
        if (!this.conversation) throw new Block("busy", `${this.ref} has no live session yet; try again once it is running`);
        return this.conversation.configure(change);
      },
    });
    this.start();
    return this;
  }

  log(line: string) {
    this.history.push({ seq: ++this.seq, line: one(clean(line), 400) });
    // Keep the opening activity as well as the tail: the start of a long run is what explains it.
    if (this.history.length > 200) this.history.splice(40, this.history.length - 200);
  }
  tail(lines = 20, since = 0) { return this.history.filter((h) => h.seq > since).slice(-lines); }
  private set(state: AgentState) {
    this.state = state;
    this.deps.telemetry?.state(this.id, state, state === "waiting" ? "ask" : state === "parked" ? "adjudicate" : undefined);
    this.log(`state ${state}`);
    this.publish();
  }
  private publish() {
    if (!this.dir) return;
    try {
      const file = join(this.dir, "record.json");
      writeFileSync(`${file}.tmp`, `${JSON.stringify({ version: 2, ...this.view(), history: this.history }, null, 2)}\n`, { mode: 0o600 });
      renameSync(`${file}.tmp`, file);
    } catch { /* the record is forensic; the live view stays authoritative */ }
  }
  view() {
    return {
      ref: this.ref, title: this.title, owner: this.owner, kind: this.kind.name, state: this.state, round: this.round, task: this.task,
      worktree: this.work, branch: this.branch, candidate: this.candidate, recoverySha: this.recoverySha, exhausted: this.exhausted, plan: this.plan?.path, error: this.error, ask: this.ask?.question,
      attachments: this.attachments.map((a) => a.path), delegations: this.delegations.map(({ question, state, error }) => ({ question, state, error })),
      reviews: this.reviews, started: this.started, finished: this.finished,
    };
  }

  /** Main's one talk verb: steer a running agent, answer an open ask, or resume a parked session. */
  send(textIn: string): string {
    const message = textIn.trim();
    if (!message) throw new Block("empty", "Nothing to send");
    switch (this.state) {
      case "running":
        this.log(`← main: ${message}`);
        this.conversation?.deliver(`Main: ${message}`);
        return `Steered ${this.ref}`;
      case "waiting":
        this.log(`← main: ${message}`);
        this.ask?.resolve(`Main: ${message}`);
        return `Answered ${this.ref}`;
      case "parked":
        this.log(`← main: ${message}`);
        this.wakeParked?.(`Main: ${message}`);
        return `Resumed ${this.ref} (round ${this.round + 1})`;
      case "starting": case "reviewing":
        throw new Block("busy", `${this.ref} is ${this.state}; wait for its next message`);
      default:
        throw new Block("ended", `${this.ref} is ${this.state}`);
    }
  }
  /** Close a parked agent; stop a live one. Bounded. */
  async cancel() {
    if (this.ended) return;
    if (this.state === "parked") this.wakeParked?.(undefined);
    else {
      this.deps.telemetry?.state(this.id, "cancelling");
      this.controller.abort(new Block("cancelled", "Cancelled by Main"));
    }
    this.start();
    let timer: ReturnType<typeof setTimeout> | undefined;
    await Promise.race([this.done.catch(() => {}), new Promise<void>((resolve) => { timer = setTimeout(resolve, 15_000); })]);
    clearTimeout(timer);
  }

  private get children(): SubagentDeps {
    const { driver, semaphore, telemetry, sessions } = this.deps;
    return { driver, semaphore, runtime: () => this.conversation?.runtime ?? this.deps.runtime, telemetry, sessions, warning: this.warning,
      launched: (role, runtime, label) => { this.launches.push({ role, runtime, label }); } };
  }

  private async run() {
    const { prompts, limits, root, driver } = this.deps;
    const signal = this.signal;
    let box: ReturnType<typeof processTools> | undefined;
    try {
      signal.throwIfAborted();
      this.dir ??= await agentDirectory(this.deps.state, this.ref);
      const write = this.kind.access === "write";
      if (write) {
        this.project = await baselineProject(root, signal);
        this.work = await worktree(this.project, this.dir, this.branch!, signal);
        this.log(`worktree on ${this.branch} from ${this.project.baseline.slice(0, 10)}`);
      }
      const cwd = this.work ?? root;
      const tools: Tool[] = [...readTools(cwd), this.delegateTool(cwd), this.askTool()];
      if (write) {
        box = processTools(cwd, join(this.dir, "runtime"), { signal });
        tools.push(...writeTools(cwd), ...box.tools);
      }
      const unreviewed = this.reviewed ? "" : "\n\nNo independent review runs for this agent; submit a self-contained result.";
      this.conversation = new Conversation({
        driver, signal, warning: this.warning, turns: limits.agentTurns, minutes: limits.agentMinutes, pending: () => this.openPqs,
        spec: { runtime: this.deps.runtime, observe: this.deps.telemetry?.sink(this.id), name: `agent.${this.kind.name}`, cwd, tools, ...(this.kind.skill ? { skills: [this.kind.skill] } : {}), system: `${prompts.protocol}\n\n${this.kind.prompt}${unreviewed}`, log: (line) => this.log(line) },
        finish: {
          schema: Submission,
          description: `Submit your result${this.reviewed ? " for independent review" : ""}.${write ? "" : " Worq saves it to .agents/plans/."}`,
          validate: () => { if (this.openPqs) throw new Block("pq-open", `PQs ${this.delegations.filter((d) => d.state === "queued" || d.state === "running").map((d) => JSON.stringify(d.question)).join(", ")} are still open: end your turn to wait for their answers, then submit.`); },
        },
      });
      let message: string | undefined = JSON.stringify({ task: this.task, kind: this.kind.name, ...(this.attachments.length ? { attachments: this.attachments } : {}) }, null, 2);
      while (message !== undefined) {
        this.round++;
        this.exhausted = this.recoverySha = undefined;
        this.set("running");
        try { await this.submit(await this.conversation.run(message)); }
        catch (error) {
          // Budget exhaustion keeps the last response and partial work; Main may resume with a fresh budget.
          if (signal.aborted || this.conversation.disposed || !(error instanceof Block && (error.code === "turn-limit" || error.code === "time-limit"))) throw error;
          this.exhausted = errorText(error);
          const partial = this.work && await pin(this.work, signal, `worq ${this.ref}: round ${this.round} partial (unreviewed)`);
          if (partial && partial !== this.candidate) this.recoverySha = partial;
        }
        message = await this.park();
      }
      this.state = "closed";
    } catch (error) {
      if (signal.aborted) this.state = "cancelled";
      else { this.error = errorText(error); this.state = "failed"; }
    } finally {
      this.controller.abort(new Block("ended", "Agent ended"));
      this.deps.sessions?.delete(this.id);
      for (const d of this.delegations) if (d.state === "queued" || d.state === "running") d.state = "cancelled";
      this.ask?.resolve(UNANSWERED);
      this.conversation?.dispose();
      await box?.close().catch((error) => { this.error ??= errorText(error); });
      if (this.work && this.project) {
        // Never remove the only copy of interrupted work.
        try {
          const recovered = await pin(this.work, AbortSignal.timeout(30_000), `worq ${this.ref}: ${this.state}`);
          if (recovered !== this.candidate) {
            this.recoverySha = recovered;
            this.log(`Recovery SHA ${recovered}: UNVERIFIED / not merge-ready`);
          }
          await removeWorktree(this.project.root, this.work);
          this.work = undefined;
        } catch (error) {
          this.log(`Worktree retained at ${this.work}: ${errorText(error)}`);
        }
      }
      const telemetry = this.deps.telemetry;
      telemetry?.state(this.id, this.state, this.state === "failed" ? "failure" : undefined);
      const interrupted = telemetry?.live.get(this.id);
      if (interrupted?.status === "reviewing") telemetry?.revision({ ...interrupted, status: "inconclusive" }, true);
      telemetry?.live.delete(this.id);
      telemetry?.changed();
      this.finished = Date.now();
      this.log(`state ${this.state}`);
      this.publish();
      // After cleanup, so Main sees the final state (worktree gone, progress pinned on the branch).
      if (this.state === "failed") this.deps.notify({ type: "failed", ref: this.ref, text: `${this.headline} failed: ${this.error}${this.work ? `\nWorktree retained at ${this.work}.` : this.branch ? `\nProgress kept on ${this.branch}.` : ""}\nLast activity:\n${this.tail(10).map((h) => h.line).join("\n")}` });
    }
  }

  /** Wait for Main: a message resumes the same session, close or idle expiry ends it. */
  private park(): Promise<string | undefined> {
    this.set("parked");
    this.deps.notify({ type: "parked", ref: this.ref, text: this.digest() });
    return new Promise((resolve) => {
      const done = (message: string | undefined) => {
        clearTimeout(timer);
        this.signal.removeEventListener("abort", abort);
        this.wakeParked = undefined;
        resolve(message);
      };
      const abort = () => done(undefined);
      const timer = setTimeout(() => { this.log(`idle for ${this.deps.limits.idleMinutes}m; closing`); done(undefined); }, this.deps.limits.idleMinutes * 60_000);
      timer.unref?.();
      this.signal.addEventListener("abort", abort, { once: true });
      this.wakeParked = done;
    });
  }

  private delegateTool(cwd: string): Tool {
    return tool("delegate",
      "Delegate one probing question (PQ) to a fresh read-only subagent. Fire and forget: returns the question now; the answer arrives later as a [PQ] message headed by that question. Use only for independent, bounded questions answerable by reading.",
      obj({ question: text(800), why: text(400), name: Type.Optional(Type.String({ pattern: "^[a-z][a-z0-9-]{0,31}$" })) }), ({ question, why, name }) => {
        if (this.delegations.length >= this.deps.limits.subagents) throw new Block("pq-limit", `PQ limit (${this.deps.limits.subagents}) reached; investigate directly`);
        const d: Delegation = { role: name ? `subagent.${name}` : "subagent", id: `d${this.delegations.length + 1}`, question, why, state: "queued" };
        this.delegations.push(d);
        this.log(`→ PQ: ${question}`);
        void this.pq(d, cwd);
        return `Delegated PQ: ${question}\nKeep working, or end your turn to wait for the [PQ] answer.`;
      });
  }
  private async pq(d: Delegation, cwd: string) {
    const { prompts, limits } = this.deps;
    const result = await runSubagent(this.children, {
      key: `${this.id}:${d.id}`, parent: this.id, ref: this.ref, role: d.role, row: "PQ", question: clean(d.question).replace(/\s+/g, " ").trim(),
      label: `PQ ${d.question}`, title: `${this.title} · ${d.question}`, consequence: "Cancels this question; the parent is told it went unanswered.",
      system: prompts.pq, payload: JSON.stringify({ question: d.question, why: d.why, context: this.task.slice(0, 2000) }, null, 2),
      schema: PqAnswer, description: "Return your answer to the probing question.", turns: limits.subagentTurns, minutes: limits.subagentMinutes,
      cwd, signal: this.signal, log: (line) => this.log(`PQ ${d.question}: ${line}`), started: () => { d.state = "running"; },
    });
    if (this.signal.aborted) return;
    if ("value" in result) { d.answer = result.value; d.state = "answered"; }
    else { d.state = result.cancelled ? "cancelled" : "failed"; d.error = result.error; }
    this.log(`← PQ ${d.state}: ${d.question}`);
    this.conversation?.deliver(pqMessage(d.question, d.answer, d.error, d.state === "cancelled"));
  }
  private askTool(): Tool {
    return tool("ask_main",
      "Ask Main (the user's Pi session) one concise question about user-owned intent, scope or permission that the task and repository cannot settle. Blocks until answered.",
      obj({ question: text(1200) }), async ({ question }, toolSignal) => {
        if (++this.asks > this.deps.limits.asks) return "Ask limit reached. Do not assume authorization. Report the unresolved decision.";
        const signal = AbortSignal.any([this.signal, toolSignal]);
        const conversation = this.conversation;
        conversation?.pause();
        this.set("waiting");
        let timer: ReturnType<typeof setTimeout> | undefined;
        try {
          return await new Promise<string>((resolve, reject) => {
            this.ask = { question, resolve };
            timer = setTimeout(() => resolve(UNANSWERED), this.deps.limits.askMinutes * 60_000);
            timer.unref?.();
            signal.addEventListener("abort", () => reject(signal.reason), { once: true });
            this.deps.notify({ type: "ask", ref: this.ref, text: `${this.headline} asks:\n${question}\n\nAnswer with worq_send(ref "${this.ref}"). Answer yourself when this conversation or the repository settles it; during planning, defer unresolved preferences to plan approval using provisional assumptions or alternatives. Never assume permission.` });
          });
        } finally {
          clearTimeout(timer);
          this.ask = undefined;
          if (this.state === "waiting") this.set("running");
          conversation?.resume();
        }
      });
  }

  /** Record the submission (plan file or pinned commit), then one independent review when required. */
  private async submit(report: Submission) {
    const signal = this.signal;
    this.set("reviewing");
    let identity: Revision["identity"];
    if (this.kind.access === "read") {
      const path = `.agents/plans/plan-${this.ref}.md`;
      const markdown = planMarkdown({ ref: this.ref, title: this.title, kind: this.kind.name, round: this.round, task: this.task, report });
      await writeScoped(this.deps.root, path, markdown, { create: !this.plan });
      identity = { digest: createHash("sha256").update(markdown, "utf8").digest("hex") };
      this.plan = { path, text: markdown };
      this.submission = markdown;
      this.log(`plan saved to ${path}`);
    } else {
      this.candidate = await pin(this.work!, signal, `worq ${this.ref}: round ${this.round}`);
      identity = { sha: this.candidate };
      this.diffstat = await git(this.work!, signal, "diff", "--stat", this.project!.baseline, this.candidate) || "No changes from the baseline";
      this.submission = reportText(report);
      this.log(`candidate ${this.candidate.slice(0, 10)}`);
    }
    if (!this.reviewed) return;
    const revision: Revision = { run: this.id, round: this.round, identity, status: "reviewing" };
    this.deps.telemetry?.revision(revision);
    const review = await this.runReview();
    this.reviews.push(review);
    this.deps.telemetry?.revision({ ...revision, status: review.verdict, review: { findings: review.findings?.map((f) => f.need === true) ?? [], artifacts: review.artifacts?.length ?? 0 } }, true);
  }
  private async runReview(): Promise<ReviewRecord> {
    const { prompts, limits, root } = this.deps;
    const round = this.round;
    const candidate = this.candidate!;
    const dir = this.dir!;
    let saved: string[] = [];
    const workspace = this.kind.access === "write" ? async (signal: AbortSignal): Promise<Workspace> => {
      const scratch = join(dir, `review-${round}`);
      await mkdir(scratch, { mode: 0o700 });
      const cwd = await snapshot(root, scratch, candidate, signal);
      const box = processTools(cwd, join(scratch, "runtime"), { signal, verify: { artifacts: join(dir, "artifacts", `r${round}`), services: limits.services } });
      return {
        cwd, tools: [...readTools(cwd), ...box.tools],
        check: async (s) => { saved = box.saved; return await intact(cwd, candidate, s) ? undefined : "Reviewer changed tracked files or the checked-out commit"; },
        close: async () => { await box.close().catch(() => {}); await rm(scratch, { recursive: true, force: true }).catch(() => {}); },
      };
    } : undefined;
    const result = await runSubagent(this.children, {
      key: `${this.id}:r${round}`, parent: this.id, ref: this.ref, role: "review", row: "review", review: { round },
      label: `review · round ${round}`, title: this.title, consequence: "Cancels this review; it is recorded as inconclusive.",
      system: prompts.review, schema: ReviewReport, description: "Return your independent review.", turns: limits.reviewerTurns, minutes: limits.reviewerMinutes,
      payload: JSON.stringify({
        request: this.task, kind: this.kind.name, round, submission: this.submission,
        ...(this.attachments.length ? { plans: this.attachments } : {}),
        ...(this.kind.access === "write" ? { commit: candidate, diffstat: this.diffstat } : {}),
      }, null, 2),
      cwd: root, signal: this.signal, log: (line) => this.log(`  review ${line}`), workspace,
    });
    this.signal.throwIfAborted();
    if ("error" in result) return { round, verdict: "inconclusive", error: result.cancelled ? "Review cancelled by Main" : `Review error: ${result.error}` };
    return { round, ...result.value, verdict: result.value.verdict as Verdict, artifacts: [...(result.value.artifacts ?? []), ...saved] };
  }

  /** Display-only round notice; `worq_list` holds the full findings. */
  digest() {
    const close = "worq_send resumes this session with corrections; worq_cancel closes it. This notice does not authorize further action.";
    if (this.exhausted) return [
      `${this.headline} round ${this.round} parked: ${this.exhausted}. Nothing was submitted or reviewed.`,
      `Last response: ${one(this.conversation?.last || "none", 1500)}`,
      ...(this.recoverySha ? [`Partial commit ${this.recoverySha}: UNVERIFIED / not merge-ready`] : []),
      `worq_send resumes with a fresh budget; worq_cancel closes it.`,
    ].join("\n");
    const where = this.kind.access === "write" ? `Branch ${this.branch} @ ${this.candidate}\n${this.diffstat}` : `Plan: ${this.plan?.path}`;
    return [`${this.headline} round ${this.round} parked · ${this.reviewed ? reviewStatus(this.review) : "unreviewed"}`, where,
      ...(this.reviewed ? reviewLines(this.review, { ...DIGEST, label: `worq_list(${this.ref})` }) : []),
      `Full findings: worq_list(${this.ref}). ${close}`,
    ].join("\n");
  }
}
